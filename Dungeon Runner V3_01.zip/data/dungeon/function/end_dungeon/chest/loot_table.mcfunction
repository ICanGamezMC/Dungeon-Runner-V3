
$function $(text)